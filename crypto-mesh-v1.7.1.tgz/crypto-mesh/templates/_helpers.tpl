{{/*
Expand the name of the chart.
*/}}

{{- define "cert-orchestrator.name" -}}
{{- default .Chart.Name .Values.certOrchestrator.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "cert-orchestrator.fullname" -}}
{{- if .Values.certOrchestrator.fullnameOverride -}}
{{- .Values.certOrchestrator.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.certOrchestrator.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "cert-orchestrator.serviceAccountName" -}}
{{- if .Values.certOrchestrator.serviceAccount.create -}}
    {{ default (include "cert-orchestrator.fullname" .) .Values.certOrchestrator.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.certOrchestrator.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Namespace for all resources to be installed into
If not defined in values file then the helm release namespace is used
By default this is not set so the helm release namespace will be used

This gets around an problem within helm discussed here
https://github.com/helm/helm/issues/5358
*/}}
{{- define "cert-orchestrator.namespace" -}}
    {{ .Values.certOrchestrator.namespace | default .Release.Namespace }}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chartName" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Labels that should be added on each resource
*/}}
{{- define "labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- if eq (default "helm" .Values.creator) "helm" }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "chartName" . }}
{{- end -}}
{{- if .Values.certOrchestrator.global.commonLabels}}
{{ toYaml .Values.certOrchestrator.global.commonLabels }}
{{- end }}
{{- end -}}

