# crypto-mesh

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational?style=flat-square) ![AppVersion: v1.0](https://img.shields.io/badge/AppVersion-v1.0-informational?style=flat-square)

A Helm chart for crypto-mesh

**Homepage:** <https://www.appviewx.com/>

## Requirements

Kubernetes: `>= 1.19.6-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| appviewxCSIProvider.enabled | bool | `false` | enable the appviewx-csi-provider |
| appviewxCSIProvider.image.pullPolicy | string | `"IfNotPresent"` |  |
| appviewxCSIProvider.image.repository | string | `"docker.io/appviewx/appviewx-csi-provider"` |  |
| appviewxCSIProvider.image.tag | string | `"master_dev"` |  |
| appviewxCSIProvider.maxWaitCount | int | `24` | retry count for the appviewx-csi-provider to wait for the certificate to be created |
| appviewxCSIProvider.podLabels | object | `{}` | Pod Labels to be added to the appviewx-csi-provider pods |
| appviewxCSIProvider.tolerations[0].effect | string | `"NoExecute"` |  |
| appviewxCSIProvider.tolerations[0].key | string | `"node.kubernetes.io/not-ready"` |  |
| appviewxCSIProvider.tolerations[0].operator | string | `"Exists"` |  |
| appviewxCSIProvider.tolerations[0].tolerationSeconds | int | `60` |  |
| appviewxCSIProvider.tolerations[1].effect | string | `"NoExecute"` |  |
| appviewxCSIProvider.tolerations[1].key | string | `"node.kubernetes.io/unreachable"` |  |
| appviewxCSIProvider.tolerations[1].operator | string | `"Exists"` |  |
| appviewxCSIProvider.tolerations[1].tolerationSeconds | int | `60` |  |
| appviewxInfraOrchestrator.enabled | bool | `false` | enable the appviewx-infra-orchestrator |
| appviewxInfraOrchestrator.image.pullPolicy | string | `"IfNotPresent"` |  |
| appviewxInfraOrchestrator.image.repository | string | `"docker.io/appviewx/appviewx-infra-orchestrator"` |  |
| appviewxInfraOrchestrator.image.tag | string | `"master_dev"` |  |
| appviewxInfraOrchestrator.podLabels | object | `{}` | Pod Labels to be added to the appviewx-infra-orchestrator pods |
| appviewxInfraOrchestrator.tick | string | `"60m"` | Infra discovery retry time period in minutes |
| appviewxInfraOrchestrator.tolerations[0].effect | string | `"NoSchedule"` |  |
| appviewxInfraOrchestrator.tolerations[0].key | string | `"node-role.kubernetes.io/control-plane"` |  |
| appviewxInfraOrchestrator.tolerations[0].operator | string | `"Exists"` |  |
| appviewxInfraOrchestrator.tolerations[1].effect | string | `"NoSchedule"` |  |
| appviewxInfraOrchestrator.tolerations[1].key | string | `"node-role.kubernetes.io/master"` |  |
| appviewxInfraOrchestrator.tolerations[1].operator | string | `"Exists"` |  |
| appviewxSigner.enabled | bool | `false` | enable the appviewx-signer |
| certOrchestrator.autoTrigger.workflow | bool | `false` | enable the workflow to be triggered automatically based on the configmap with valid annotations and data |
| certOrchestrator.clusterResourceNamespace | string | `""` |  |
| certOrchestrator.discovery.appviewxGroupName | string | `"Default"` | default group name to be used |
| certOrchestrator.discovery.credentialSecretName | string | `"appviewx-auth"` | name of the secret used for authentication with AppViewX |
| certOrchestrator.discovery.credentialSecretNamespace | string | `"crypto-mesh"` | namespace of the secret used for authentication with AppViewX |
| certOrchestrator.discovery.enabled | bool | `true` | enable the discovery of the certificates from the secret |
| certOrchestrator.discovery.isGroupAutoGenerate | bool | `true` | enable the creation of the groups at AppViewX based on the discovery for each cluster and their namespaces |
| certOrchestrator.discovery.isPrivateKeyDiscovery | bool | `false` | enable the discovery of the private keys from the secret |
| certOrchestrator.discovery.isSecretCacheBackUpEnabled | bool | `true` | enable the Secret cache backup - This will cache the metadata of uploaded certificates in the secret to avoid re-uploading the same certificate |
| certOrchestrator.discovery.secretSyncPeriodInMinutes | int | `60` | Time in minutes to sync the secrets from the cluster to AppViewX |
| certOrchestrator.enabled | bool | `true` | enable the cert-orchestrator |
| certOrchestrator.envConfigMapName | string | `""` | Name of the ConfigMap to be used for the environment variables |
| certOrchestrator.envSecretName | string | `""` | Name of the Secret to be used for the environment variables |
| certOrchestrator.extraArgs | list | `[]` |  |
| certOrchestrator.extraEnv | list | `[]` |  |
| certOrchestrator.featureGates | string | `""` |  |
| certOrchestrator.global.clusterName | string | `"kubeplus"` | name of the cluster in the AppViewX Inventory |
| certOrchestrator.global.commonLabels | object | `{}` |  |
| certOrchestrator.global.ingressSyncPeriodInMinutes | int | `360` | Time in minutes to sync the ingress from the cluster to AppViewX |
| certOrchestrator.global.k8sVendor | string | `"Self-Managed"` | type of vendor for the cluster |
| certOrchestrator.global.leaderElection.namespace | string | `"kube-system"` | Override the namespace used for the leader election lease |
| certOrchestrator.global.logLevel | int | `5` | Set the verbosity of cert-orchestrator. Range of 1 - 7 with 7 being the most verbose. |
| certOrchestrator.global.rbac.aggregateClusterRoles | bool | `true` |  |
| certOrchestrator.global.rbac.create | bool | `true` |  |
| certOrchestrator.image.pullPolicy | string | `"IfNotPresent"` |  |
| certOrchestrator.image.repository | string | `"docker.io/appviewx/cert-orchestrator"` |  |
| certOrchestrator.image.tag | string | `"master-dev"` |  |
| certOrchestrator.imagePullSecretName | string | `"regcred"` | image pull secret name - used to pull the image from the private registry |
| certOrchestrator.imageRbacProxy.pullPolicy | string | `"IfNotPresent"` |  |
| certOrchestrator.imageRbacProxy.repository | string | `"quay.io/brancz/kube-rbac-proxy"` |  |
| certOrchestrator.imageRbacProxy.tag | string | `"v0.13.0"` |  |
| certOrchestrator.isAuthenticationSecretEncryptionRequired | bool | `true` | Encrypt the authentication secret on first time use |
| certOrchestrator.namespace | string | `"crypto-mesh"` | namespace in which the cert-orchestrator is installed |
| certOrchestrator.podLabels | object | `{}` | Pod Labels to be added to the cert-orchestrator pods |
| certOrchestrator.renewalEnabled | bool | `true` |  |
| certOrchestrator.replicaCount | int | `1` | replica count for the cert-orchestrator, Recommended value is 1 |
| certOrchestrator.resources.limits.cpu | string | `"1000m"` |  |
| certOrchestrator.resources.limits.memory | string | `"1Gi"` |  |
| certOrchestrator.resources.requests.cpu | string | `"500m"` |  |
| certOrchestrator.resources.requests.memory | string | `"500Mi"` |  |
| certOrchestrator.serviceAccount.automountServiceAccountToken | bool | `true` |  |
| certOrchestrator.serviceAccount.create | bool | `true` |  |
| certOrchestrator.strategy | object | `{}` |  |
| certOrchestrator.tolerations[0].effect | string | `"NoExecute"` |  |
| certOrchestrator.tolerations[0].key | string | `"node.kubernetes.io/not-ready"` |  |
| certOrchestrator.tolerations[0].operator | string | `"Exists"` |  |
| certOrchestrator.tolerations[0].tolerationSeconds | int | `60` |  |
| certOrchestrator.tolerations[1].effect | string | `"NoExecute"` |  |
| certOrchestrator.tolerations[1].key | string | `"node.kubernetes.io/unreachable"` |  |
| certOrchestrator.tolerations[1].operator | string | `"Exists"` |  |
| certOrchestrator.tolerations[1].tolerationSeconds | int | `60` |  |

